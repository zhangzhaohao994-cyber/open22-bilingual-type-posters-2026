# OPEN 22 双语大字文字海报｜15 个全新版式

这是第 22 届 OPEN 国际行为艺术节的第二轮 15 张纯文字海报。全部使用中英双语：01–10 以中文为主视觉，11–15 以英文为主视觉。每张都重新建立版面骨架，不再使用统一页脚；艺术家、团队、策展人、时间、地点、主协办和摄影摄像全部进入主要构图。

- `posters/01.png` 至 `posters/15.png`：1200 × 1800 PNG
- `poster.html?id=1` 至 `poster.html?id=15`：可编辑 HTML/CSS 海报
- `source/design-prompt.md`：专业设计提示词
- `source/research.md`：审美研究与开源工具依据
- `contact-sheet.png`：15 版总览

文字校订：`Highest`、`（）`、`Mia`。
