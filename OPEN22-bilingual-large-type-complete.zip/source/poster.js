const D={
 artists:[
  ['比尔·艾奇森','英国','Bill Aitchison','United Kingdom'],['蔡青','德国','Cai Qing','Germany'],['克洛代尔·T.','加拿大','Claudelle T.','Canada'],['埃里克·勒图尔诺·迪梅纳','加拿大','Éric Létourneau Dumaine','Canada'],['最高','中国','Highest','China'],['朱莉·安德烈·T.','加拿大','Julie Andrée T.','Canada'],['金微','英国','KIMVI Jin Wei','United Kingdom'],['吕德生','中国','Lü Desheng','China'],['玛丽安娜·帕普斯特','瑞士','Marianne Papst','Switzerland'],['吴以强','中国','Wu Yiqiang','China'],['一方','中国','Yi Fang','China'],['（）','中国','（）','China']
 ],
 team:[['甘丽君','Gan Lijun'],['刘新山','Liu Xinshan'],['陈永栋','Chen Yongdong'],['王宏伟','Wang Hongwei'],['赵晓凯','Zhao Xiaokai'],['叶月明','Ye Yueming'],['吕子云','Lü Ziyun'],['米亚','Mia']],
 facts:[
  ['curator','策展人 / CURATOR','陈进（中国）','Chen Jin (China)'],
  ['opening','开幕 / OPENING','2026年10月24日下午2:00','October 24, 2026, 2:00 PM'],
  ['schedule','作品实施 / PERFORMANCE SCHEDULE','2026年10月24日至25日　每日14:00–18:00 / 19:00–21:00','October 24–25, 2026　Daily 2:00–6:00 PM / 7:00–9:00 PM'],
  ['venue','地点 / VENUE','浙江省衢州市开化县音坑镇下淤村63号 OPEN艺术空间','OPEN Art Space, No. 63, Xiayu Village, Yinkeng Town, Kaihua County, Quzhou, Zhejiang Province, China'],
  ['organizer','主办 / ORGANIZER','OPEN艺术空间','OPEN Art Space'],
  ['coorg','协办 / CO-ORGANIZERS','下淤村委会 · 向村艺术咖啡 · 下淤美术馆 · 汉唐香府','Xiayu Village Committee · Xiangcun Art Café · Xiayu Art Museum · Hantang Xiangfu'],
  ['photo','摄影摄像 / PHOTO & VIDEO','王昕炜 · 李帅','Wang Xinwei · Li Shuai']
 ]
};
const logo='<img class="logo" src="assets/open-logo-original.png" alt="OPEN艺术节Logo">';
const mast=(extra='')=>`<header class="mast ${extra}"><span class="kicker">第22届 / THE 22ND</span><h1>OPEN</h1><h2>国际行为艺术节</h2><p>INTERNATIONAL PERFORMANCE ART FESTIVAL</p></header>`;
const artists=(extra='')=>`<section class="artists ${extra}" aria-label="参展艺术家 Participating Artists">${D.artists.map((x,i)=>`<article class="artist a${i+1}"><span class="zh"><b>${x[0]}</b><i>${x[1]}</i></span><span class="en"><b>${x[2]}</b><i>${x[3]}</i></span></article>`).join('')}</section>`;
const team=(extra='')=>`<section class="team ${extra}"><h3>OPEN艺术节团队成员 / OPEN FESTIVAL TEAM</h3><div>${D.team.map(x=>`<span class="member"><b>${x[0]}</b><i>${x[1]}</i></span>`).join('')}</div></section>`;
const facts=(extra='')=>`<section class="facts ${extra}">${D.facts.map(x=>`<article class="fact ${x[0]}"><h3>${x[1]}</h3><b>${x[2]}</b><span>${x[3]}</span></article>`).join('')}</section>`;
const all=(cls,extra='')=>`${logo}<div class="frame ${cls}">${mast()}${artists()}${team()}${facts()}${extra}</div>`;
const P={
 1:()=>all('mosaic'),
 2:()=>all('vertical'),
 3:()=>all('broadsheet'),
 4:()=>all('cute'),
 5:()=>all('classic'),
 6:()=>all('staircase'),
 7:()=>all('orbit'),
 8:()=>all('mirror'),
 9:()=>all('terminal'),
 10:()=>all('scriptflow'),
 11:()=>all('english-giant'),
 12:()=>all('columns'),
 13:()=>all('fashion'),
 14:()=>all('diagonal'),
 15:()=>all('quilt'),
 16:()=>all('reference-layout',`<div class="slogan"><b>行为，连接世界</b><span>Performance Connects the World</span></div>`),
 17:()=>all('reference-layout',`<div class="slogan"><b>行为，连接世界</b><span>Performance Connects the World</span></div>`)
};
const id=Math.max(1,Math.min(17,Number(new URLSearchParams(location.search).get('id')||1)));
const root=document.querySelector('#poster');root.className=`poster p${String(id).padStart(2,'0')}`;root.dataset.poster=id;root.innerHTML=P[id]();document.title=`OPEN 22 bilingual poster ${String(id).padStart(2,'0')}`;
